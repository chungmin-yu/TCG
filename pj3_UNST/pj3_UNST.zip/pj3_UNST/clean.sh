rm -rf gogui-twogtp-2022*
rm record*
