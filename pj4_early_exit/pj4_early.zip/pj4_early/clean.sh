rm -rf gogui-twogtp-2023*
